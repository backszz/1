<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'db.php';
    
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin_dashboard.php');
        exit;
    } else {
        $error = "用户名或密码错误";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>管理员登录 - 京东支付系统</title>
    <style>
        :root {
            --primary-color: #e4393c;
            --secondary-color: #f5f5f5;
            --text-color: #333;
            --success-color: #52c41a;
            --error-color: #ff4d4f;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Microsoft Yahei', Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            width: 100%;
            max-width: 400px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transform: translateY(-20px);
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            width: 60px;
            margin-bottom: 15px;
        }

        h2 {
            color: var(--primary-color);
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .subtitle {
            color: #666;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #eee;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 8px rgba(228, 57, 60, 0.2);
            outline: none;
        }

        .error-message {
            color: var(--error-color);
            font-size: 0.85rem;
            margin-top: 8px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        button {
            width: 100%;
            padding: 12px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        button:hover {
            background: #c73134;
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(228, 57, 60, 0.3);
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
                margin: 0 10px;
            }

            h2 {
                font-size: 1.5rem;
            }

            input {
                padding: 10px 12px;
            }

            button {
                padding: 12px;
            }
        }

        /* 加载动画 */
        .loader {
            display: none;
            border: 3px solid #f3f3f3;
            border-radius: 50%;
            border-top: 3px solid var(--primary-color);
            width: 20px;
            height: 20px;
            animation: spin 0.8s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="jd-logo.png" alt="京东" class="logo">
            <h2>管理后台登录</h2>
            <p class="subtitle">京东支付系统管理平台</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error-message show"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <div class="form-group">
                <input type="text" name="username" placeholder="用户名" required autofocus>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="密码" required>
            </div>
            <button type="submit">
                <span class="button-text">登录</span>
                <div class="loader"></div>
            </button>
        </form>
    </div>

    <script>
        // 表单提交动画
        const form = document.getElementById('loginForm');
        const buttonText = document.querySelector('.button-text');
        const loader = document.querySelector('.loader');

        form.addEventListener('submit', function(e) {
            buttonText.style.display = 'none';
            loader.style.display = 'block';
        });

        // 输入验证
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                if (this.checkValidity()) {
                    this.classList.remove('invalid');
                } else {
                    this.classList.add('invalid');
                }
            });
        });
    </script>
</body>
</html>